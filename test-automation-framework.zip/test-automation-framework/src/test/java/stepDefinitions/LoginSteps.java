package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.*;
import static org.junit.Assert.*;

public class LoginSteps {
    WebDriver driver;

    @Given("I am on the login page")
    public void i_am_on_login_page() {
        driver = new ChromeDriver();
        driver.get("https://example.com/login");
    }

    @When("I enter valid username and password")
    public void enter_credentials() {
        // Aquí va el código para ingresar usuario y contraseña
    }

    @Then("I should see the dashboard")
    public void see_dashboard() {
        String title = driver.getTitle();
        assertEquals("Dashboard", title);
        driver.quit();
    }
}
